public class StringCalculator {
	// addcount
	public static int addCount;
	
	
	//method to used add
	public static int add(String numbers) throws Exception {
		String errorNumber = "";
		++addCount;
		int sum = 0;
		if(numbers == null || numbers.length() == 0)
			return sum;
		String tmp = numbers.replaceAll("\\D", ",");
		//System.out.println(tmp);
	    String[] charsArray = tmp.split(",");
	    for (int i = 0; i < charsArray.length; i++) {
	    	if(!charsArray[i].isBlank()) {
	    		int temp = Integer.parseInt(charsArray[i]);
	    		System.out.println(temp);
	    		
	    		if(temp < 0) {
	    			errorNumber = errorNumber.concat(" "+temp);
	    			continue;
	    		}
	    		
	    		if(temp <= 1000) {
	    			sum = sum + temp;
	    		} 
	    	}
	    }
	    
	    if(errorNumber.length() >0) {
	    	throw new Exception("negatives not allowed");
	    }
		return sum;
	}

	//method to return count for add invoke
	public int GetCalledCount() {
		return addCount;
	}

}
